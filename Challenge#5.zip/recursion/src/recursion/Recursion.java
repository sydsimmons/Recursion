/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package recursion;

import java.util.Scanner;

/**
 *
 * @author syd
 */
public class Recursion {

    /**
     * @param args the command line arguments
     */
    
    /** uses a do-while loop to ask the user to input a word 
     * prints the string before recursion 
     * then calls the recurse method and prints after recursion 
     * then ask if they want to repeat 
     */
    public static void main(String[] args) { 
        String before; 
        String repeat = "yes";
        Scanner keyboard = new Scanner(System.in); 
         
         
        do { 
            System.out.println("Please type a word. "); 
            
            before = keyboard.nextLine();  
            System.out.println("Before recursion: " + before);  
            
            String after = recurse(before);  
            System.out.println("After recursion: " + after); 
            
            System.out.println("Would like to try a new word? (yes or no)");  
            repeat = keyboard.nextLine();
            
        }while (repeat.equalsIgnoreCase("yes"));
    } 
    
    public static String recurse(String word) { 
        
        if (word == "") { //base case
            return "";
        } 
        else if (word.charAt(0) == 'x'){
            return 'y'+ recurse(word.substring(1));
        } 
        else {
             return word.charAt(0) + recurse(word.substring(1)); 
            
        }
    }
    
}
